create function notify_specs_update() returns trigger
    language plpgsql
as
$$
    begin
        PERFORM pg_notify('update_spec', 'specs was updated');
        return new;
    end;
    $$;

alter function notify_specs_update() owner to mock;

